<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Keluarga;

class KeluargaController extends Controller
{
    public function index()
    {
       $keluargas= Keluarga::all();
       return view('keluarga.index',['keluargas'=> $keluargas]);
    }

    public function create(){
        return view('keluarga.create');
    }

    public function store(Request $request)
    {

        $validateData = $request->validate([
             'nama' => 'required|min:3|max:50',
             'jenis_kelamin' => 'required|in:P,L',
             'tingkatan' => 'required',
        ]);
        Keluarga::create($validateData);

         return redirect()->route('keluargas.index')
         ->with('pesan',"Penambahan data {$validateData['nama']} Berhasil");
    }

    public function show($keluarga)
    {
        $result = Keluarga::findOrFail($keluarga);
        return view('keluarga.show',['keluarga' => $result]);

    }

    public function edit(Keluarga $keluarga)
    {
            return view('keluarga.edit',['keluarga'=> $keluarga]);
    }
     public function update(Request $request, Keluarga $keluarga)
    {
        $validateData = $request->validate([
            'nama' => 'required|min:3|max:50'.$keluarga->id,
            'jenis_kelamin' => 'required|in:P,L',
            'tingkatan' => 'required',
       ]);
       Keluarga::where('id', $keluarga->id)->update($validateData);
       return redirect()->route('keluargas.show',['keluarga'=>$keluarga->id])
       ->with('pesan',"Update data {$validateData['nama']} Berhasil");;
    }

    public function destroy(Keluarga $keluarga)
    {
        $keluarga->delete();
        return redirect()->route('keluargas.index')
        ->with('pesan',"Hapus data $keluarga->nama berhasil");
    }
}
