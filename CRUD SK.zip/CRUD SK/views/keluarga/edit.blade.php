<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <title>Edit Data Anggota</title>
</head>
<body>
    <div class="container pt-4 bg-white">
        <div class="row">
            <div class="col-md-8 col-xl-6">
                <h1>Edit Data</h1>
                <hr>

                <form action="{{ route('keluargas.update',['keluarga' => $keluarga->id]) }}"
                     method="POST">
                     @method('PUT')
                    @csrf
                    <div class="mb-3">
                         <label class="form-label" for="nama">Nama Lengkap</label>
                         <input type="text" id="nama" name="nama" value="{{ old('nama') ?? $keluarga->nama}}"
                         class="form-control @error('nama') is-invalid @enderror">
                         @error('nama')
                         <div class="text-danger">{{ $message }}</div>
                         @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Jenis Kelamin</label>
                        <div class="d-flex">
                            <div class="form-check me-3">
                                <input class="form-check-input" type="radio" name="jenis_kelamin" id="laki_laki" value="L" {{ (old('jenis_kelamin') ?? $keluarga->jenis_kelamin) =='L' ? 'checked': ''}}>
                                <label for="laki_laki" class="form-check-label">Laki-laki</label>
                            </div>
                            <div class="form-check">
                                <input type="radio" class="form-check-input" name="jenis_kelamin"
                                id="perempuan" value="P" {{ (old('jenis_kelamin')  ?? $keluarga->jenis_kelamin) =='P' ? 'checked': ''}}>
                                <label for="perempuan" class="form-check-label">Perempuan</label>
                            </div>
                        </div>
                        @error('jenis_kelamin')
                             <div class="text-danger">{{ $message }}</div>
                        @enderror
                   </div>

                   <div class="mb-3">
                        <label class="form-label" for="tingkatan">Masukkan No Tingkatan</label>
                         <input type="text" id="tingkatan" name="tingkatan" value="{{ old('tingkatan') ?? $keluarga->tingkatan }}"
                        class="form-control @error('tingkatan') is-invalid @enderror">
                        @error('tingkatan')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>

                    <button type="submit" class="btn btn-primary mb-2">Update</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
