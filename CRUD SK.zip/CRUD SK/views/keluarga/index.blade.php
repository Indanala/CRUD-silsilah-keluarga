<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <title>Pendaftaran Angota Silsilah Keluarga</title>
</head>
<body>
    <div class="container mt-3">
        <div class="row">
            <div class="col-12">

            <div class="py-4 d-flex justify-content-between align-items-center">
                <h2>Tabel Silsilah Keluarga</h2>
                <a href="{{ route('keluargas.create')}}" class="btn btn-primary">
                Tambah Anggota</a>
            </div>
            @if(session()->has('pesan'))
            <div class="alert alert-success">
                    {{ session()->get('pesan')}}
            </div>
            @endif

            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Jenis Kelamin</th>
                        <th>Tingkatan</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($keluargas as $keluarga)
                    <tr>
                        <th>{{$loop->iteration}}</th>
                        <td><a href="{{ route('keluargas.show',['keluarga' => $keluarga->id]) }}">{{$keluarga->nama}}</a></td>
                        <td>{{$keluarga->jenis_kelamin == 'P'?'Perempuan':'Laki-laki'}}</td>
                        <td>{{$keluarga->tingkatan}}</td>
                    </tr>
                    @empty
                    <td colspan="6" class="text-center">Tidak ada data...</td>
                    @endforelse

                </tbody>
            </table>
            </div>
        </div>
    </div>
</body>
</html>
