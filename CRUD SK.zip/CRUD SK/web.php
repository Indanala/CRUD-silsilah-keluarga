<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\KeluargaController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//menampilkan isi tabel keluarga diproses oleh method index()
//pada KeluargaController dengan nama 'keluarga.index'
Route::get('/keluargas', [KeluargaController::class,'index'])
 ->name('keluargas.index');

 //menampilkan form input
 Route::get('/keluargas/create', [KeluargaController::class,'create'])
 ->name('keluargas.create');


 //memproses hasil form dan meng inputkannya kedalam database
 Route::post('/keluargas', [KeluargaController::class,'store'])
 ->name('keluargas.store');

 Route::get('/keluargas/{keluarga}', [KeluargaController::class,'show'])
->name('keluargas.show');

Route::get('/keluargas/{keluarga}/edit', [KeluargaController::class,'edit'])
->name('keluargas.edit');


//update tabel
Route::put('/keluargas/{keluarga}', [KeluargaController::class,'update'])
->name('keluargas.update');

//delete
Route::delete('/keluarga/{keluarga}', [keluargaController::class,'destroy'])
->name('keluargas.destroy');



